"use strict";
exports.id = 2958;
exports.ids = [2958];
exports.modules = {

/***/ 2958:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useUser)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5941);
/* harmony import */ var _utils_fetcher__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3367);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swr__WEBPACK_IMPORTED_MODULE_2__]);
swr__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




function useUser({ redirectTo ="" , redirectIfFound =false ,  } = {}) {
    const { data: user , mutate: mutateUser  } = (0,swr__WEBPACK_IMPORTED_MODULE_2__["default"])("/api/user", _utils_fetcher__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        // if no redirect needed, just return (example: already on /dashboard)
        // if user data not yet there (fetch in progress, logged in or not) then don't do anything yet
        if (!redirectTo || !user) return;
        if (// If redirectTo is set, redirect if the user was not found.
        redirectTo && !redirectIfFound && !user?.isLoggedIn || // If redirectIfFound is also set, redirect if the user was found
        redirectIfFound && user?.isLoggedIn) {
            next_router__WEBPACK_IMPORTED_MODULE_1___default().push(redirectTo);
        }
    }, [
        user,
        redirectIfFound,
        redirectTo
    ]);
    return {
        user,
        mutateUser
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3367:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const fetcher = (url)=>fetch(url).then((res)=>res.json());
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (fetcher);


/***/ })

};
;