(() => {
var exports = {};
exports.id = 6885;
exports.ids = [6885];
exports.modules = {

/***/ 9562:
/***/ ((module) => {

// Exports
module.exports = {
	"messages": "messages_messages__TIWS0",
	"message": "messages_message__L9LRn",
	"you": "messages_you___ybsG",
	"interlocutor": "messages_interlocutor__cyKjH",
	"input": "messages_input__vYE8k"
};


/***/ }),

/***/ 6319:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "d": () => (/* binding */ sessionOptions)
/* harmony export */ });
const sessionOptions = {
    password: "secret-passwordsecret-passwordsecret-passwordsecret-passwordsecret-passwordsecret-password",
    cookieName: "user-cookies",
    // secure: true,
    cookieOptions: {
        secure: "production" === "production"
    }
};


/***/ }),

/***/ 6752:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Task),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _messages_module_scss__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9562);
/* harmony import */ var _messages_module_scss__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_messages_module_scss__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _lib_session__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6319);
/* harmony import */ var iron_session_next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9531);
/* harmony import */ var _utils_rest__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1587);
/* harmony import */ var _mantine_dropzone__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7932);
/* harmony import */ var _mantine_dropzone__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mantine_dropzone__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mantine_notifications__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(914);
/* harmony import */ var _mantine_notifications__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mantine_notifications__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_bootstrap_Container__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4678);
/* harmony import */ var react_bootstrap_Container__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Container__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2247);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mantine_core__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var tabler_icons_react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1384);
/* harmony import */ var tabler_icons_react__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(tabler_icons_react__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_12__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([iron_session_next__WEBPACK_IMPORTED_MODULE_5__]);
iron_session_next__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];














const RichTextEditor = next_dynamic__WEBPACK_IMPORTED_MODULE_12___default()(null, {
    loadableGenerated: {
        modules: [
            "courses/[id]/days/[day_id]/tasks/[task_id].jsx -> " + "@mantine/rte"
        ]
    },
    ssr: false
});
function Task({ task , task_status , messages  }) {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { task_id  } = router.query;
    const { 0: chat , 1: setChat  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(messages);
    const { 1: setAcceptLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: files , 1: setFiles  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const theme = (0,_mantine_core__WEBPACK_IMPORTED_MODULE_10__.useMantineTheme)();
    const setAccepted = ()=>{
        setAcceptLoading(true);
        _utils_rest__WEBPACK_IMPORTED_MODULE_6__/* ["default"].post */ .Z.post(`/public/tasks/${task_id}/accept`).then(()=>{
            router.replace(router.asPath);
        }).catch(()=>{}).finally(()=>{});
    };
    const getIconColor = (status, theme)=>{
        return status.accepted ? theme.colors[theme.primaryColor][theme.colorScheme === "dark" ? 4 : 6] : status.rejected ? theme.colors.red[theme.colorScheme === "dark" ? 4 : 6] : theme.colorScheme === "dark" ? theme.colors.dark[0] : theme.colors.gray[7];
    };
    const dropzoneChildren = (status, theme)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_10__.Group, {
            position: "center",
            spacing: "xl",
            style: {
                minHeight: 55,
                pointerEvents: "none"
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(tabler_icons_react__WEBPACK_IMPORTED_MODULE_11__.Upload, {
                    status: status,
                    style: {
                        color: getIconColor(status, theme)
                    },
                    size: 55
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_10__.Text, {
                        size: "xl",
                        inline: true,
                        children: "Загрузите файл с выполненным заданием"
                    })
                })
            ]
        });
    const sendMessage = (e)=>{
        e.preventDefault();
        const userMessage = e.target["user-message"].value;
        if (files.length == 0) return;
        const body = new FormData();
        body.append("message", userMessage);
        if (files) {
            body.append("files", files[0]);
        }
        _utils_rest__WEBPACK_IMPORTED_MODULE_6__/* ["default"].post */ .Z.post(`/public/tasks/${task_id}/answer`, body).then((res)=>{
            e.target.reset();
            (0,_mantine_notifications__WEBPACK_IMPORTED_MODULE_8__.showNotification)({
                title: "Сообщение отправлено",
                message: "Скоро эксперты проверят выполнение задания и дадут вам ответ",
                autoClose: 3500,
                color: "green",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(tabler_icons_react__WEBPACK_IMPORTED_MODULE_11__.Check, {
                    size: 18
                })
            });
            setFiles([]);
            setChat([
                ...chat,
                res.data
            ]);
        }).catch(()=>{}).finally(()=>{});
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_3___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: "Школа талантов"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: "Generated by create next app"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_bootstrap_Container__WEBPACK_IMPORTED_MODULE_9___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_10__.Space, {
                        h: "xl"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_10__.Card, {
                        p: "lg",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                style: {
                                    color: "#036459",
                                    fontSize: "24px",
                                    fontWeight: "600"
                                },
                                children: task?.name
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(RichTextEditor, {
                                readOnly: true,
                                value: task?.description
                            }),
                            task_status !== "empty" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_10__.Space, {
                                        h: "lg"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        style: {
                                            color: "#036459",
                                            fontSize: "16px",
                                            fontWeight: "600"
                                        },
                                        children: "Скачайте материалы для работы и изучите их"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_10__.Text, {
                                        variant: "link",
                                        component: "a",
                                        href: `/${task?.files?.at(0)}`,
                                        children: [
                                            "Скачать файл ",
                                            task?.name
                                        ]
                                    }),
                                    chat.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_messages_module_scss__WEBPACK_IMPORTED_MODULE_13___default().messages),
                                        children: chat.sort((prev, next)=>Number(prev.id) - Number(next.id)).map((message)=>{
                                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: `${(_messages_module_scss__WEBPACK_IMPORTED_MODULE_13___default().message)} ${message?.answer_id ? (_messages_module_scss__WEBPACK_IMPORTED_MODULE_13___default().interlocutor) : (_messages_module_scss__WEBPACK_IMPORTED_MODULE_13___default().you)}`,
                                                children: message?.files?.at(0) ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                    children: [
                                                        message?.message,
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_10__.Text, {
                                                            variant: "link",
                                                            component: "a",
                                                            size: "sm",
                                                            download: true,
                                                            href: `/${message?.files?.at(0)}`,
                                                            children: "Скачать файл"
                                                        }, message?.id),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_10__.Space, {
                                                            h: "sm"
                                                        })
                                                    ]
                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_10__.Text, {
                                                    size: "md",
                                                    weight: 500,
                                                    children: message?.message
                                                })
                                            }, message?.id);
                                        })
                                    }),
                                    task_status !== "ready" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                            onSubmit: sendMessage,
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_10__.Space, {
                                                    h: "sm"
                                                }),
                                                files?.length > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_10__.Text, {
                                                    size: "sm",
                                                    children: [
                                                        "Прикрепленные файлы:",
                                                        " ",
                                                        files?.map((el)=>{
                                                            return ` ${el?.name},`;
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_10__.Input, {
                                                    placeholder: "Введите сообщение",
                                                    name: "user-message"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_dropzone__WEBPACK_IMPORTED_MODULE_7__.Dropzone, {
                                                    onDrop: (files)=>{
                                                        setFiles(files);
                                                    },
                                                    onReject: ()=>{
                                                        (0,_mantine_notifications__WEBPACK_IMPORTED_MODULE_8__.showNotification)({
                                                            title: "Файл отклонен",
                                                            autoClose: 3500,
                                                            color: "red",
                                                            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(tabler_icons_react__WEBPACK_IMPORTED_MODULE_11__.X, {
                                                                size: 18
                                                            })
                                                        });
                                                    },
                                                    maxSize: 3 * 4024 ** 2,
                                                    padding: "xs",
                                                    children: (status)=>dropzoneChildren(status, theme)
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_10__.Button, {
                                                    disabled: files.length == 0,
                                                    fullWidth: true,
                                                    className: "mt-1",
                                                    type: "submit",
                                                    id: "send-message",
                                                    children: "Отправить"
                                                })
                                            ]
                                        })
                                    }),
                                    task_status === "ready" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_10__.Center, {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_10__.Text, {
                                            color: "green",
                                            size: "xl",
                                            weight: 700,
                                            children: "Вы выполнили задание, можете приступать к выполнению следующих"
                                        })
                                    })
                                ]
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                style: {
                                    fontSize: "16px",
                                    color: "white",
                                    fontWeight: "600",
                                    padding: "10px",
                                    borderRadius: "5px",
                                    border: "none",
                                    backgroundColor: "#1FBEAC"
                                },
                                onClick: ()=>setAccepted(true),
                                children: "Приступить к выполнению"
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
const getServerSideProps = (0,iron_session_next__WEBPACK_IMPORTED_MODULE_5__/* .withIronSessionSsr */ .c)(async function getServerSideProps({ req , query  }) {
    if (!req.cookies["user-cookies"]) {
        return {
            redirect: {
                destination: "/auth",
                permanent: false
            }
        };
    }
    const { task_id  } = query;
    const response = await _utils_rest__WEBPACK_IMPORTED_MODULE_6__/* ["default"].get */ .Z.get(`/public/tasks/${task_id}`, {
        headers: {
            Cookie: `user-cookies=${req.cookies["user-cookies"]};`
        }
    });
    let course = {};
    let day = {};
    let task = [];
    let task_status = "empty";
    let messages = [];
    if (response.status === 200) {
        course = response.data.course;
        day = response.data.day;
        task = response.data.task;
        task_status = response.data.task_status;
        messages = response.data.messages;
    }
    return {
        props: {
            course: course,
            day: day,
            task: task,
            task_status: task_status,
            messages: messages,
            user: req.session.user
        }
    };
}, _lib_session__WEBPACK_IMPORTED_MODULE_4__/* .sessionOptions */ .d);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1587:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ rest)
});

;// CONCATENATED MODULE: external "axios"
const external_axios_namespaceObject = require("axios");
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_namespaceObject);
;// CONCATENATED MODULE: ./utils/rest.js

(external_axios_default()).defaults.baseURL = "https://camp.future-mission.ru/api";
/* harmony default export */ const rest = ((external_axios_default()));


/***/ }),

/***/ 2247:
/***/ ((module) => {

"use strict";
module.exports = require("@mantine/core");

/***/ }),

/***/ 7932:
/***/ ((module) => {

"use strict";
module.exports = require("@mantine/dropzone");

/***/ }),

/***/ 914:
/***/ ((module) => {

"use strict";
module.exports = require("@mantine/notifications");

/***/ }),

/***/ 5832:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 4678:
/***/ ((module) => {

"use strict";
module.exports = require("react-bootstrap/Container");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 1384:
/***/ ((module) => {

"use strict";
module.exports = require("tabler-icons-react");

/***/ }),

/***/ 1454:
/***/ ((module) => {

"use strict";
module.exports = import("iron-session");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9531,5152], () => (__webpack_exec__(6752)));
module.exports = __webpack_exports__;

})();