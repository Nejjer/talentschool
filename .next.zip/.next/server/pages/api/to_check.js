"use strict";
(() => {
var exports = {};
exports.id = 2311;
exports.ids = [2311];
exports.modules = {

/***/ 1454:
/***/ ((module) => {

module.exports = import("iron-session");;

/***/ }),

/***/ 4371:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "d": () => (/* binding */ sessionOptions)
/* harmony export */ });
const sessionOptions = {
    password: "secret-passwordsecret-passwordsecret-passwordsecret-passwordsecret-passwordsecret-password",
    cookieName: "user-cookies",
    // secure: true,
    cookieOptions: {
        secure: "production" === "production"
    }
};


/***/ }),

/***/ 3268:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var iron_session_next__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8534);
/* harmony import */ var _lib_session__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4371);
/* harmony import */ var _utils_database__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5138);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([iron_session_next__WEBPACK_IMPORTED_MODULE_0__]);
iron_session_next__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const tasksCheckHandler = async (req, res)=>{
    const { method  } = req;
    switch(method){
        case "GET":
            const tasks = await _utils_database__WEBPACK_IMPORTED_MODULE_2__/* ["default"].select */ .Z.select("*").from("tasks");
            const days = await _utils_database__WEBPACK_IMPORTED_MODULE_2__/* ["default"].select */ .Z.select("*").from("days");
            const users = await _utils_database__WEBPACK_IMPORTED_MODULE_2__/* ["default"].select */ .Z.select("*").from("users");
            const currentUser = req.session.user;
            const checkCurator = users.find((user)=>user.email === currentUser.email);
            const isCurator = checkCurator.status === "curator";
            const curatorId = isCurator && checkCurator.id;
            const to_check = await _utils_database__WEBPACK_IMPORTED_MODULE_2__/* ["default"].select */ .Z.select("*").from("accepted_tasks").where({
                status: "check"
            });
            const to_check_for_curator = await _utils_database__WEBPACK_IMPORTED_MODULE_2__/* ["default"].select */ .Z.select("*").from("accepted_tasks").whereIn("status", [
                "check",
                "waiting"
            ]);
            const adminId = users.find((user)=>user.status == "admin").id;
            const curatorAccepteds = to_check_for_curator.filter((check)=>check.user_id == curatorId && check.user_id != adminId);
            const curatorTasks = curatorAccepteds.map((ac)=>ac.task_id);
            const byTaskId = to_check_for_curator.filter((tch)=>curatorTasks.includes(tch.task_id) && tch.user_id != adminId);
            let to_check_ready = [];
            const usersWithoutAdmin = users.filter((user)=>user.status !== "admin");
            if (currentUser.status == "curator") {
                for (let forCurator of byTaskId){
                    const user = usersWithoutAdmin.find((user)=>user.id == forCurator.user_id);
                    const task = tasks.find((task)=>task.id == forCurator.task_id);
                    const day = days.find((day)=>day.id == task.day_id);
                    const course = await _utils_database__WEBPACK_IMPORTED_MODULE_2__/* ["default"].select */ .Z.select("*").from("courses").where({
                        id: day.course_id
                    }).limit(1);
                    if (!user || !task || !day || !course) continue;
                    to_check_ready.push({
                        user,
                        task: {
                            ...task,
                            satus: "check"
                        },
                        day,
                        course: course[0]
                    });
                }
                res.status(200).json(to_check_ready);
                break;
            }
            for (let to_check_el of to_check){
                const user1 = users.find((user)=>user.id == to_check_el.user_id);
                const task1 = tasks.find((task)=>task.id == to_check_el.task_id);
                const day1 = days.find((day)=>day.id == task1.day_id);
                const course1 = await _utils_database__WEBPACK_IMPORTED_MODULE_2__/* ["default"].select */ .Z.select("*").from("courses").where({
                    id: day1.course_id
                }).limit(1);
                to_check_ready.push({
                    day: day1,
                    user: user1,
                    course: course1[0],
                    task: {
                        ...task1,
                        status: "check"
                    }
                });
            }
            res.status(200).json(to_check_ready);
            break;
        default:
            res.setHeader("Allow", [
                "GET"
            ]);
            res.status(405).end(`Method ${method} Not Allowed`);
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,iron_session_next__WEBPACK_IMPORTED_MODULE_0__/* .withIronSessionApiRoute */ .n)(tasksCheckHandler, _lib_session__WEBPACK_IMPORTED_MODULE_1__/* .sessionOptions */ .d));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5138:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ utils_database)
});

;// CONCATENATED MODULE: external "knex"
const external_knex_namespaceObject = require("knex");
var external_knex_default = /*#__PURE__*/__webpack_require__.n(external_knex_namespaceObject);
;// CONCATENATED MODULE: ./utils/database.js

const database = external_knex_default()({
    client: "pg",
    connection: {
        host: "213.189.221.182",
        port: 5432,
        user: "camp",
        password: "Ph5nuX0HHDPorRGP",
        database: "camp"
    }
});
/* harmony default export */ const utils_database = (database);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8534], () => (__webpack_exec__(3268)));
module.exports = __webpack_exports__;

})();