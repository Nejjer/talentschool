"use strict";
(() => {
var exports = {};
exports.id = 5765;
exports.ids = [5765];
exports.modules = {

/***/ 1454:
/***/ ((module) => {

module.exports = import("iron-session");;

/***/ }),

/***/ 4371:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "d": () => (/* binding */ sessionOptions)
/* harmony export */ });
const sessionOptions = {
    password: "secret-passwordsecret-passwordsecret-passwordsecret-passwordsecret-passwordsecret-password",
    cookieName: "user-cookies",
    // secure: true,
    cookieOptions: {
        secure: "production" === "production"
    }
};


/***/ }),

/***/ 1407:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var iron_session_next__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8534);
/* harmony import */ var _lib_session__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4371);
/* harmony import */ var _utils_database__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5138);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([iron_session_next__WEBPACK_IMPORTED_MODULE_0__]);
iron_session_next__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



async function getConnectedCoureses(course_id) {
    //получение user id в функции, чтобы просто вызвать, а не переписать одно и тоже
    const connected_courses = await _utils_database__WEBPACK_IMPORTED_MODULE_2__/* ["default"].select */ .Z.select("user_id").from("connected_courses").where("course_id", course_id);
    return connected_courses;
}
const courseUsersHandler = async (req, res)=>{
    const { method  } = req;
    const body = req.body;
    const { id  } = req.query;
    const exists_course = await _utils_database__WEBPACK_IMPORTED_MODULE_2__/* ["default"].select */ .Z.select("*").from("courses").where({
        id: id
    }).limit(1);
    if (exists_course.length <= 0) {
        res.status(410).json({
            errorMessage: "Course not exists"
        });
        return;
    }
    switch(method){
        case "GET":
            const connected_courses = await getConnectedCoureses(exists_course[0].id);
            const connected_users = await _utils_database__WEBPACK_IMPORTED_MODULE_2__/* ["default"].select */ .Z.select("email", "id").from("users").whereIn("id", connected_courses.map((el)=>el.user_id));
            res.status(200).json(connected_users);
            break;
        //в этом case должен обрабатываться запрос, сначала запись в бд
        case "POST":
            // тут insert ом добавляем в бд, потом по логике которая тут была {получаем id курса 
            // и по нему всех user ов подписанных на него. он дает новый массив и это отправляем в front-ui}
            await (0,_utils_database__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)("connected_courses").insert({
                user_id: body.id,
                course_id: Number(exists_course[0].id)
            });
            const refetched_connected_courses = await getConnectedCoureses(Number(exists_course[0].id));
            const get_after_creating_new_user_for_connected_courses = await _utils_database__WEBPACK_IMPORTED_MODULE_2__/* ["default"].select */ .Z.select("email", "id").from("users").whereIn("id", refetched_connected_courses.map((el)=>el.user_id));
            res.status(200).json(get_after_creating_new_user_for_connected_courses);
            break;
        case "DELETE":
            await (0,_utils_database__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)("connected_courses").where({
                course_id: Number(exists_course[0].id),
                user_id: Number(req.query.user_id)
            }).del();
            const refetched_connected_courses_after_delete = await getConnectedCoureses(exists_course[0].id);
            const get_after_deleting_new_user_for_connected_courses = await _utils_database__WEBPACK_IMPORTED_MODULE_2__/* ["default"].select */ .Z.select("email", "id").from("users").whereIn("id", refetched_connected_courses_after_delete.map((el)=>el.user_id));
            res.status(200).json(get_after_deleting_new_user_for_connected_courses);
            break;
        default:
            res.setheader("allow", [
                "get"
            ]);
            res.status(405).end(`method ${method} not allowed`);
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,iron_session_next__WEBPACK_IMPORTED_MODULE_0__/* .withIronSessionApiRoute */ .n)(courseUsersHandler, _lib_session__WEBPACK_IMPORTED_MODULE_1__/* .sessionOptions */ .d));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5138:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ utils_database)
});

;// CONCATENATED MODULE: external "knex"
const external_knex_namespaceObject = require("knex");
var external_knex_default = /*#__PURE__*/__webpack_require__.n(external_knex_namespaceObject);
;// CONCATENATED MODULE: ./utils/database.js

const database = external_knex_default()({
    client: "pg",
    connection: {
        host: "213.189.221.182",
        port: 5432,
        user: "camp",
        password: "Ph5nuX0HHDPorRGP",
        database: "camp"
    }
});
/* harmony default export */ const utils_database = (database);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8534], () => (__webpack_exec__(1407)));
module.exports = __webpack_exports__;

})();