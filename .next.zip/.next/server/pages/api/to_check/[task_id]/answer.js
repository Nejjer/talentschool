"use strict";
(() => {
var exports = {};
exports.id = 1441;
exports.ids = [1441];
exports.modules = {

/***/ 2616:
/***/ ((module) => {

module.exports = require("formidable");

/***/ }),

/***/ 1454:
/***/ ((module) => {

module.exports = import("iron-session");;

/***/ }),

/***/ 4371:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "d": () => (/* binding */ sessionOptions)
/* harmony export */ });
const sessionOptions = {
    password: "secret-passwordsecret-passwordsecret-passwordsecret-passwordsecret-passwordsecret-password",
    cookieName: "user-cookies",
    // secure: true,
    cookieOptions: {
        secure: "production" === "production"
    }
};


/***/ }),

/***/ 7465:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var iron_session_next__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8534);
/* harmony import */ var _lib_session__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4371);
/* harmony import */ var formidable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2616);
/* harmony import */ var formidable__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(formidable__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils_saveFile__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3657);
/* harmony import */ var _utils_database__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5138);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([iron_session_next__WEBPACK_IMPORTED_MODULE_0__]);
iron_session_next__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const config = {
    api: {
        bodyParser: false
    }
};
const mainAnswerHandler = async (req, res)=>{
    const { method  } = req;
    const { task_id  } = req.query;
    switch(method){
        case "POST":
            const form = new (formidable__WEBPACK_IMPORTED_MODULE_2___default().IncomingForm)();
            form.parse(req, async (err, fields, files)=>{
                if (err) {
                    res.status(500).json({
                        errorMessage: "Error"
                    });
                    return;
                }
                let path = [];
                for (let key of Object.keys(files)){
                    path.push((0,_utils_saveFile__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(files[key]));
                }
                const user = await _utils_database__WEBPACK_IMPORTED_MODULE_4__/* ["default"].select */ .Z.select("*").from("users").where({
                    email: req.session.user.email
                }).limit(1);
                await (0,_utils_database__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)("notifications").insert({
                    notification_type: `accept_task_${user[0].status === "user" ? "user" : "admin"}`,
                    params: {
                        task_id: task_id,
                        user_id: user[0].id,
                        new_status: fields.status
                    }
                });
                if (user[0].status === "user") {
                    const new_id = await (0,_utils_database__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)("task_messages").returning("id").insert({
                        task_id: task_id,
                        user_id: user[0].id,
                        message: fields.message,
                        files: JSON.stringify(path)
                    });
                    await (0,_utils_database__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)("accepted_tasks").update({
                        status: fields.status
                    }).where({
                        task_id: task_id,
                        user_id: user[0].id
                    });
                    res.status(200).json({
                        id: new_id[0].id,
                        user_id: user[0].id,
                        task_id: task_id,
                        message: fields.message,
                        files: path
                    });
                } else {
                    const new_id1 = await (0,_utils_database__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)("task_messages").returning("id").insert({
                        task_id: task_id,
                        user_id: fields.user_id,
                        date: JSON.stringify(new Date()),
                        message: fields.message,
                        files: JSON.stringify(path),
                        answer_id: user[0].id
                    });
                    await (0,_utils_database__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)("accepted_tasks").update({
                        status: fields.status
                    }).where({
                        task_id: task_id,
                        user_id: fields.user_id
                    });
                    res.status(200).json({
                        id: new_id1[0].id,
                        user_id: user[0].id,
                        answer_id: user[0].id,
                        task_id: task_id,
                        message: fields.message,
                        files: path
                    });
                }
            });
            break;
        case "PUT":
            const { task_id: task_id1  } = req.query;
            await (0,_utils_database__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)("accepted_tasks").where({
                task_id: task_id1
            }).update({
                status: "waiting"
            });
            res.status(200).json({
                edited: true
            });
            break;
        default:
            res.setHeader("Allow", [
                "POST",
                "PUT"
            ]);
            res.status(405).end(`Method ${method} Not Allowed`);
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,iron_session_next__WEBPACK_IMPORTED_MODULE_0__/* .withIronSessionApiRoute */ .n)(mainAnswerHandler, _lib_session__WEBPACK_IMPORTED_MODULE_1__/* .sessionOptions */ .d));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5138:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ utils_database)
});

;// CONCATENATED MODULE: external "knex"
const external_knex_namespaceObject = require("knex");
var external_knex_default = /*#__PURE__*/__webpack_require__.n(external_knex_namespaceObject);
;// CONCATENATED MODULE: ./utils/database.js

const database = external_knex_default()({
    client: "pg",
    connection: {
        host: "213.189.221.182",
        port: 5432,
        user: "camp",
        password: "Ph5nuX0HHDPorRGP",
        database: "camp"
    }
});
/* harmony default export */ const utils_database = (database);


/***/ }),

/***/ 3657:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ utils_saveFile)
});

;// CONCATENATED MODULE: external "fs"
const external_fs_namespaceObject = require("fs");
var external_fs_default = /*#__PURE__*/__webpack_require__.n(external_fs_namespaceObject);
;// CONCATENATED MODULE: ./utils/saveFile.js

const saveFile = (file)=>{
    const data = external_fs_default().readFileSync(file.filepath);
    external_fs_default().writeFileSync(`./public/storage/${file.originalFilename}`, data);
    external_fs_default().unlinkSync(file.filepath);
    return `storage/${file.originalFilename}`;
};
/* harmony default export */ const utils_saveFile = (saveFile);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8534], () => (__webpack_exec__(7465)));
module.exports = __webpack_exports__;

})();